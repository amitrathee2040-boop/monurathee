import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { flushSync } from "react-dom";

import { Sparkles, Download, Loader2, Wand2, Dice5, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { toast } from "sonner";
import { InstallPWAButton } from "@/components/install-pwa-button";
import { getAllHistory, addHistoryItem, clearAllHistory, type HistoryItem } from "@/lib/history-db";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lumen — AI Text-to-Image Generator" },
      { name: "description", content: "Generate stunning AI images from text. 100 free credits every day. No signup required." },
    ],
  }),
  component: Generator,
});

const STYLES = [
  { id: "realistic", label: "Realistic" },
  { id: "anime", label: "Anime" },
  { id: "cinematic", label: "Cinematic" },
  { id: "portrait", label: "Portrait" },
  { id: "fashion", label: "Fashion" },
  { id: "product", label: "Product" },
  { id: "architecture", label: "Architecture" },
  { id: "youtube", label: "YouTube Thumbnail" },
];
const RATIOS = [
  { id: "1:1", label: "1:1 Square", w: 1024, h: 1024 },
  { id: "9:16", label: "9:16 Portrait", w: 1024, h: 1536 },
  { id: "16:9", label: "16:9 Landscape", w: 1536, h: 1024 },
  { id: "4:5", label: "4:5 Portrait", w: 1024, h: 1280 },
  { id: "3:2", label: "3:2 Landscape", w: 1536, h: 1024 },
  { id: "custom", label: "Custom Size", w: 1024, h: 1024 },
];
const QUALITIES = [
  { id: "hd", label: "HD" },
  { id: "fhd", label: "Full HD" },
  { id: "2k", label: "2K" },
  { id: "4k", label: "4K" },
];

const DAILY_CREDITS = 100;
const CREDITS_KEY = "lumen.credits";

type CreditState = { remaining: number; resetAt: number };

function loadCredits(): CreditState {
  try {
    const raw = localStorage.getItem(CREDITS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CreditState;
      if (Date.now() - parsed.resetAt < 24 * 60 * 60 * 1000) return parsed;
    }
  } catch {}
  return { remaining: DAILY_CREDITS, resetAt: Date.now() };
}
function saveCredits(c: CreditState) { localStorage.setItem(CREDITS_KEY, JSON.stringify(c)); }

function Generator() {
  const [credits, setCredits] = useState<CreditState>({ remaining: DAILY_CREDITS, resetAt: Date.now() });
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    setCredits(loadCredits());
    getAllHistory().then(setHistory);
  }, []);

  const [prompt, setPrompt] = useState("");
  const [negative, setNegative] = useState("");
  const [style, setStyle] = useState("realistic");
  const [ratio, setRatio] = useState("1:1");
  const [customW, setCustomW] = useState(1024);
  const [customH, setCustomH] = useState(1024);
  const [quality, setQuality] = useState("hd");
  const [numImages, setNumImages] = useState(1);
  const [seed, setSeed] = useState<string>("");

  const [results, setResults] = useState<{ src: string; isFinal: boolean }[]>([]);
  const [viewer, setViewer] = useState<HistoryItem | null>(null);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!prompt.trim()) throw new Error("Enter a prompt");
      const current = loadCredits();
      if (current.remaining < numImages) throw new Error("Out of credits — resets every 24 hours.");
      const ratioObj = RATIOS.find((r) => r.id === ratio)!;
      const w = ratio === "custom" ? customW : ratioObj.w;
      const h = ratio === "custom" ? customH : ratioObj.h;

      setResults(Array.from({ length: numImages }, () => ({ src: "", isFinal: false })));

      for (let i = 0; i < numImages; i++) {
        const finalUrl = await generateOne(i, w, h);
        // spend 1 credit per successful image
        const after = loadCredits();
        const updated = { remaining: Math.max(0, after.remaining - 1), resetAt: after.resetAt };
        saveCredits(updated);
        setCredits(updated);

        const item: HistoryItem = {
          id: `${Date.now()}-${i}`,
          src: finalUrl,
          prompt,
          style,
          ratio,
          createdAt: Date.now(),
        };
        await addHistoryItem(item);
        setHistory((prev) => [item, ...prev]);
      }
    },
    onError: (e: any) => toast.error(e.message || "Generation failed"),
  });

  async function generateOne(idx: number, w: number, h: number): Promise<string> {
    let attempt = 0;
    let lastErr: any;
    while (attempt < 2) {
      try {
        const res = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt, negative_prompt: negative || null, style,
            width: w, height: h, quality,
          }),
        });
        if (!res.ok) {
          let raw = "";
          try {
            const j = await res.json();
            raw = typeof j?.error === "string" ? j.error : JSON.stringify(j?.error ?? j);
          } catch {
            try { raw = await res.text(); } catch {}
          }
          if (res.status === 429) {
            throw new Error("Rate limit exceeded. Please try again in a moment.");
          }
          throw new Error(raw || "Generation failed");
        }


        const json = (await res.json()) as { b64_json: string; mimeType?: string };
        if (!json?.b64_json) throw new Error("No image returned");
        const dataUrl = `data:${json.mimeType || "image/png"};base64,${json.b64_json}`;
        flushSync(() => {
          setResults((prev) => {
            const next = [...prev];
            next[idx] = { src: dataUrl, isFinal: true };
            return next;
          });
        });
        return dataUrl;

      } catch (e: any) {
        lastErr = e;
        attempt++;
      }
    }
    throw lastErr;
  }

  async function downloadAs(src: string, fmt: "png" | "jpg") {
    const blob = await (await fetch(src)).blob();
    let outBlob = blob;
    if (fmt === "jpg") {
      const img = new Image();
      const url = URL.createObjectURL(blob);
      await new Promise((r) => { img.onload = r; img.src = url; });
      const c = document.createElement("canvas");
      c.width = img.width; c.height = img.height;
      const ctx = c.getContext("2d")!;
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0);
      outBlob = await new Promise<Blob>((res) => c.toBlob((b) => res(b!), "image/jpeg", 0.95));
      URL.revokeObjectURL(url);
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(outBlob);
    a.download = `lumen-${Date.now()}.${fmt}`;
    a.click();
  }

  async function clearHistory() {
    await clearAllHistory();
    setHistory([]);
  }

  const resetsIn = Math.max(0, 24 * 60 * 60 * 1000 - (Date.now() - credits.resetAt));
  const resetsInHrs = Math.ceil(resetsIn / (60 * 60 * 1000));

  return (
    <div className="min-h-[100dvh] pb-[env(safe-area-inset-bottom)]">
      <header className="sticky top-0 z-40 glass border-b safe-pt">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-3 safe-px sm:h-16">
          <Link to="/" className="flex items-center gap-2 font-display text-base font-bold sm:text-lg">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-primary to-primary-glow shadow-glow">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-gradient">Lumen</span>
          </Link>
          <div className="flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-xs sm:gap-2 sm:px-3 sm:text-sm">
            <Sparkles className="h-3.5 w-3.5 text-primary-glow" />
            <span className="font-medium tabular-nums">{credits.remaining}</span>
            <span className="text-muted-foreground">/ {DAILY_CREDITS}</span>
            <span className="hidden text-xs text-muted-foreground sm:inline">· resets in {resetsInHrs}h</span>
          </div>
          <InstallPWAButton />
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-4 py-4 safe-px sm:gap-6 sm:py-6 lg:grid-cols-[380px,1fr]">
        <aside className="glass space-y-4 rounded-2xl p-4 sm:space-y-5 sm:p-5">
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Prompt</Label>
            <Textarea
              placeholder="A neon-lit cyberpunk alley after rain, cinematic..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="mt-1.5 min-h-[110px] resize-none"
            />
          </div>
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Negative prompt</Label>
            <Textarea
              placeholder="blurry, low quality, watermark"
              value={negative}
              onChange={(e) => setNegative(e.target.value)}
              className="mt-1.5 min-h-[60px] resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Style</Label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STYLES.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Quality</Label>
              <Select value={quality} onValueChange={setQuality}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {QUALITIES.map((q) => <SelectItem key={q.id} value={q.id}>{q.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Aspect ratio</Label>
            <Select value={ratio} onValueChange={setRatio}>
              <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
              <SelectContent>
                {RATIOS.map((r) => <SelectItem key={r.id} value={r.id}>{r.label}</SelectItem>)}
              </SelectContent>
            </Select>
            {ratio === "custom" && (
              <div className="mt-2 grid grid-cols-2 gap-2">
                <Input type="number" min={256} max={2048} step={64} value={customW} onChange={(e) => setCustomW(+e.target.value)} placeholder="Width" />
                <Input type="number" min={256} max={2048} step={64} value={customH} onChange={(e) => setCustomH(+e.target.value)} placeholder="Height" />
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Images</Label>
              <div className="mt-1.5 flex gap-1.5">
                {[1, 2, 4].map((n) => (
                  <Button key={n} type="button" variant={numImages === n ? "default" : "outline"} size="sm" className="flex-1" onClick={() => setNumImages(n)}>
                    {n}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Seed</Label>
              <div className="mt-1.5 flex gap-1.5">
                <Input value={seed} onChange={(e) => setSeed(e.target.value)} placeholder="Random" />
                <Button type="button" variant="outline" size="icon" onClick={() => setSeed(String(Math.floor(Math.random() * 1e9)))}>
                  <Dice5 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <Button
            disabled={mutation.isPending || credits.remaining < numImages}
            onClick={() => mutation.mutate()}
            className="h-12 w-full bg-gradient-to-r from-primary to-primary-glow text-base text-primary-foreground shadow-glow hover:opacity-90 active:scale-[0.99]"
          >
            {mutation.isPending ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating…</>
            ) : (
              <><Wand2 className="mr-2 h-4 w-4" /> Generate ({numImages} credit{numImages > 1 ? "s" : ""})</>
            )}
          </Button>

          {credits.remaining < numImages && (
            <p className="text-center text-xs text-destructive">
              Not enough credits. Resets in {resetsInHrs}h.
            </p>
          )}
        </aside>

        <section className="space-y-6">
          {results.length === 0 ? (
            <EmptyState />
          ) : (
            <div className={`grid gap-4 ${results.length === 1 ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2"}`}>
              {results.map((r, i) => (
                <div key={i} className="glass overflow-hidden rounded-2xl">
                  <div className="relative aspect-square">
                    {r.src ? (
                      <img
                        src={r.src}
                        alt="Generated"
                        className={`h-full w-full object-cover transition-[filter] duration-500 ${r.isFinal ? "" : "blur-2xl"}`}
                      />
                    ) : (
                      <div className="shimmer h-full w-full" />
                    )}
                    {!r.isFinal && r.src && (
                      <div className="absolute right-3 top-3 flex items-center gap-2 rounded-full bg-background/80 px-3 py-1 text-xs backdrop-blur">
                        <Loader2 className="h-3 w-3 animate-spin" /> Rendering…
                      </div>
                    )}
                  </div>
                  {r.isFinal && (
                    <div className="flex gap-2 p-3">
                      <Button size="sm" variant="outline" className="flex-1" onClick={() => downloadAs(r.src, "png")}>
                        <Download className="mr-1.5 h-3.5 w-3.5" /> PNG
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1" onClick={() => downloadAs(r.src, "jpg")}>
                        <Download className="mr-1.5 h-3.5 w-3.5" /> JPG
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {history.length > 0 && (
            <div>
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">History</h3>
                <Button variant="ghost" size="sm" onClick={clearHistory}>
                  <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Clear
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                {history.map((h) => (
                  <button
                    key={h.id}
                    type="button"
                    onClick={() => setViewer(h)}
                    className="group glass relative overflow-hidden rounded-xl text-left active:scale-[0.99] transition-transform"
                  >
                    <img src={h.src} alt={h.prompt} className="aspect-square w-full object-cover" />
                    <div className="pointer-events-none absolute inset-0 flex items-end bg-gradient-to-t from-black/80 via-black/20 to-transparent p-2 opacity-0 transition-opacity group-hover:opacity-100">
                      <p className="line-clamp-2 text-xs text-white">{h.prompt}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>

      <Dialog open={!!viewer} onOpenChange={(o) => !o && setViewer(null)}>
        <DialogContent className="max-w-3xl gap-3 p-3 sm:p-4">
          {viewer && (
            <>
              <div className="overflow-hidden rounded-xl">
                <img src={viewer.src} alt={viewer.prompt} className="max-h-[70vh] w-full object-contain" />
              </div>
              <p className="line-clamp-3 text-xs text-muted-foreground sm:text-sm">{viewer.prompt}</p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => downloadAs(viewer.src, "png")}>
                  <Download className="mr-1.5 h-4 w-4" /> PNG
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => downloadAs(viewer.src, "jpg")}>
                  <Download className="mr-1.5 h-4 w-4" /> JPG
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="glass grid min-h-[60vh] place-items-center rounded-2xl p-10 text-center">
      <div>
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-primary to-primary-glow shadow-glow">
          <Sparkles className="h-7 w-7 text-primary-foreground" />
        </div>
        <h1 className="mt-6 text-2xl font-semibold">Describe what you want to see</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          Pick a style, ratio, and quality. Hit generate — each image costs 1 credit. 100 free every 24 hours, no signup.
        </p>
      </div>
    </div>
  );
}