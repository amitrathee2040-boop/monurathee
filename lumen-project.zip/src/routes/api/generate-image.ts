import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/generate-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
        if (!LOVABLE_API_KEY) {
          return new Response(
            JSON.stringify({ error: "Missing LOVABLE_API_KEY on server" }),
            { status: 500, headers: { "content-type": "application/json" } },
          );
        }

        let body: {
          prompt: string;
          negative_prompt?: string | null;
          style?: string;
          width?: number;
          height?: number;
          quality?: "hd" | "fhd" | "2k" | "4k";
        };
        try {
          body = await request.json();
        } catch {
          return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
            status: 400,
            headers: { "content-type": "application/json" },
          });
        }

        if (!body.prompt || !body.prompt.trim()) {
          return new Response(JSON.stringify({ error: "Prompt is required" }), {
            status: 400,
            headers: { "content-type": "application/json" },
          });
        }

        const size = sizeFromDims(body.width ?? 1024, body.height ?? 1024);
        const fullPrompt = [
          stylePrefix(body.style),
          body.prompt,
          body.negative_prompt ? `Avoid: ${body.negative_prompt}` : "",
          qualityHint(body.quality),
        ]
          .filter(Boolean)
          .join(". ");

        let upstream: Response;
        try {
          upstream = await fetch(
            "https://ai.gateway.lovable.dev/v1/images/generations",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${LOVABLE_API_KEY}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model: "openai/gpt-image-2",
                prompt: fullPrompt,
                size,
                quality: "low",
                n: 1,
              }),
            },
          );
        } catch (err: any) {
          return new Response(
            JSON.stringify({
              error: `Network error contacting AI Gateway: ${err?.message ?? String(err)}`,
            }),
            { status: 502, headers: { "content-type": "application/json" } },
          );
        }

        const text = await upstream.text();
        if (!upstream.ok) {
          if (upstream.status === 429) {
            return new Response(
              JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }),
              { status: 429, headers: { "content-type": "application/json" } },
            );
          }
          if (upstream.status === 402) {
            return new Response(
              JSON.stringify({ error: "AI credits exhausted. Please add credits to your workspace." }),
              { status: 402, headers: { "content-type": "application/json" } },
            );
          }
          return new Response(
            JSON.stringify({ error: text || `AI Gateway error (${upstream.status})` }),
            { status: upstream.status, headers: { "content-type": "application/json" } },
          );
        }

        let json: any;
        try {
          json = JSON.parse(text);
        } catch {
          return new Response(
            JSON.stringify({ error: "Invalid response from AI Gateway" }),
            { status: 502, headers: { "content-type": "application/json" } },
          );
        }

        const b64 = json?.data?.[0]?.b64_json;
        if (!b64) {
          return new Response(
            JSON.stringify({ error: "No image returned from AI Gateway" }),
            { status: 502, headers: { "content-type": "application/json" } },
          );
        }

        return new Response(
          JSON.stringify({ b64_json: b64, mimeType: "image/png" }),
          { headers: { "content-type": "application/json" } },
        );
      },
    },
  },
});

function stylePrefix(style?: string) {
  switch (style) {
    case "anime":
      return "Anime style illustration, vibrant colors, detailed line art";
    case "cinematic":
      return "Cinematic photograph, dramatic lighting, film grain, shallow depth of field";
    case "portrait":
      return "Professional studio portrait, soft lighting, high detail";
    case "fashion":
      return "High-fashion editorial photo, magazine quality, stylish";
    case "product":
      return "Clean product photography on neutral background, soft shadows, marketing quality";
    case "architecture":
      return "Architectural photography, wide angle, perfect perspective, golden hour lighting";
    case "youtube":
      return "Eye-catching YouTube thumbnail, bold composition, vivid colors, high contrast";
    case "realistic":
    default:
      return "Photorealistic, ultra detailed, sharp focus";
  }
}

function sizeFromDims(w: number, h: number): "1024x1024" | "1536x1024" | "1024x1536" {
  const r = w / h;
  if (r > 1.2) return "1536x1024";
  if (r < 0.85) return "1024x1536";
  return "1024x1024";
}

function qualityHint(q?: string) {
  switch (q) {
    case "4k":
      return "Render in ultra high resolution, 4K quality, extremely detailed";
    case "2k":
      return "Render in high resolution, 2K quality, very detailed";
    case "fhd":
      return "Render in Full HD quality, detailed";
    case "hd":
    default:
      return "Render in HD quality";
  }
}
