
revoke execute on function public.has_role(uuid, public.app_role) from public, anon;
revoke execute on function public.spend_credit(uuid, int) from public, anon;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.has_role(uuid, public.app_role) to authenticated, service_role;
