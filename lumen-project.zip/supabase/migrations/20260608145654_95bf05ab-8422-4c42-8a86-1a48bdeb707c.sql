
revoke execute on function public.spend_credit(uuid, int) from authenticated;

-- Storage policies (bucket: generations, paths like <user_id>/<file>.png)
create policy "users read own generation files"
on storage.objects for select to authenticated
using (bucket_id = 'generations' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "users insert own generation files"
on storage.objects for insert to authenticated
with check (bucket_id = 'generations' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "users delete own generation files"
on storage.objects for delete to authenticated
using (bucket_id = 'generations' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "admins read all generation files"
on storage.objects for select to authenticated
using (bucket_id = 'generations' and public.has_role(auth.uid(), 'admin'));
