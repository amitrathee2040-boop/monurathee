
-- ROLES
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "users read own roles" on public.user_roles for select to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));

-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  credits_remaining int not null default 100,
  credits_reset_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create policy "read own profile" on public.profiles for select to authenticated
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));
create policy "update own profile" on public.profiles for update to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);
create policy "admins update any profile" on public.profiles for update to authenticated
  using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

-- Auto-create profile + default user role on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  insert into public.user_roles (user_id, role) values (new.id, 'user')
  on conflict do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- GENERATIONS
create table public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  prompt text not null,
  negative_prompt text,
  style text not null default 'realistic',
  aspect_ratio text not null default '1:1',
  width int not null default 1024,
  height int not null default 1024,
  quality text not null default 'hd',
  seed bigint,
  num_images int not null default 1,
  image_url text,
  status text not null default 'completed',
  error text,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.generations to authenticated;
grant all on public.generations to service_role;
alter table public.generations enable row level security;

create policy "read own generations" on public.generations for select to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "insert own generations" on public.generations for insert to authenticated
  with check (auth.uid() = user_id);
create policy "delete own generations" on public.generations for delete to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));

create index generations_user_created_idx on public.generations (user_id, created_at desc);

-- CREDITS: atomic spend with daily reset
create or replace function public.spend_credit(_user_id uuid, _amount int)
returns int language plpgsql security definer set search_path = public as $$
declare
  _remaining int;
  _reset_at timestamptz;
begin
  select credits_remaining, credits_reset_at into _remaining, _reset_at
    from public.profiles where id = _user_id for update;

  if _reset_at is null or now() - _reset_at >= interval '24 hours' then
    _remaining := 100;
    _reset_at := now();
  end if;

  if _remaining < _amount then
    raise exception 'INSUFFICIENT_CREDITS';
  end if;

  update public.profiles
    set credits_remaining = _remaining - _amount,
        credits_reset_at = _reset_at,
        updated_at = now()
    where id = _user_id;

  return _remaining - _amount;
end;
$$;

grant execute on function public.spend_credit(uuid, int) to authenticated, service_role;
